<template>
  <footer class="c-footer">
    <p>Ranek. Alguns direitos reservados.</p>
  </footer>

</template>

<script>
export default {
  name: 'Footer',

};
</script>

<style>

</style>
