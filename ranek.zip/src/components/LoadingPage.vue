<template>
  <div class="loading">
    <span class="loading__item"></span>
    <span class="loading__item"></span>
    <span class="loading__item"></span>
    <span class="loading__item"></span>
  </div>
</template>

<script>
export default {
  name: 'LoadingPage',
};
</script>

<style>

</style>
